//
//  04_06_if1.c
//  prg1
//
//  Created by k21099kk on 2021/05/06.
//

#include <stdio.h>
int main(int argc,const char * argv[])
{
    int a;
    scanf("%d",&a);
    if(a>0)
        {
        printf("aは正の値です\n");
        }
    printf("計算終了\n");
    return 0;
}
