//
//  04_01_scan.c
//  prg1
//
//  Created by k21099kk on 2021/05/06.
//

#include <stdio.h>
int main(int argc, const char * argv[])
{
    int x;
    printf("x\?\n");
    scanf("%d",&x);
    printf("x=%d\n",x);
    return 0;
}
