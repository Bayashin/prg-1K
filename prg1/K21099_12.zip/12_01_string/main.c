//
//  main.c
//  12_01_string
//
//  Created by k21099kk on 2021/07/01.
//

#include <stdio.h>

int main(int argc, const char * argv[]) {
    int size =11;
    char array[size];
    
    printf("入力(10文字以内) : ");scanf("%s",array);
    
        printf("%s\n",array);
    
    return 0;
}
