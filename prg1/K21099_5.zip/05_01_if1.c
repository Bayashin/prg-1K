//
//  05_01_if1.c
//  prg1
//
//  Created by k21099kk on 2021/05/13.
//

#include <stdio.h>
int main(int argc,const char * argv[])
{
    int a;
    printf("a\?\n");scanf("%d",&a);
    if(a>0)
        {
            printf("aは正の値です\n");
        }
    printf("計算終了\n");
    return 0;
}
