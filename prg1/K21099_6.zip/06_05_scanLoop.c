//
//  06_05_scanLoop.c
//  prg1
//
//  Created by k21099kk on 2021/05/20.
//

#include <stdio.h>
int main()
{
    int i,a;
    for(i=1;i<=5;i++){
        printf("a\?\n");scanf("%d",&a);
        printf("%d:%d\n",i,a);
    }
    return 0;
}
