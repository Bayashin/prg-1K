//
//  06_02_hello10.c
//  prg1
//
//  Created by k21099kk on 2021/05/20.
//

#include <stdio.h>
int main()
{
    int i;
    
    for(i=1;i<=10;i++){
        printf("Hello,World!\n");
    }
    return 0;
}
