//
//  06_06_even1.c
//  prg1
//
//  Created by k21099kk on 2021/05/20.
//

#include <stdio.h>
int main()
{
    int i;
    for(i=0;i<=10;i+=2){
        printf("%d\n",i);
    }
    return 0;
}
