//
//  08_03_hello10.c
//  prg1
//
//  Created by k21099kk on 2021/06/03.
//

#include <stdio.h>
int main()
{
    int i;
    
    i=1;
    
    while(i<=10){
        printf("Hello,World!\n");
        i++;
    }
    
    return 0;
}
