//
//  08_02_whileLoop.c
//  prg1
//
//  Created by k21099kk on 2021/06/03.
//

#include <stdio.h>
int main()
{
    int n;
    
    printf("n\? ");scanf("%d",&n);
    
    while(n>=0){
        printf("%d\n",n);
        n--;
    }
    
    return 0;
}
