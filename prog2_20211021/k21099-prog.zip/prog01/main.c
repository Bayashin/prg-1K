//
//  main.c
//  prog01
//
//  Created by k21099kk on 2021/10/21.
//

#include <stdio.h>

int main(int argc, const char * argv[]) {
    char c1,c2;
    int i1,i2;
    
    printf("%p\n",&c1);
    printf("%p\n",&c2);
    printf("%p\n",&i1);
    printf("%p\n",&i2);
    
    return 0;
}
