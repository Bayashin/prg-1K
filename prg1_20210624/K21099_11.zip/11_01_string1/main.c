//
//  main.c
//  11_01_string1
//
//  Created by k21099kk on 2021/06/24.
//

#include <stdio.h>
int main()
{
    char array[] = "abcde";
    printf("文字列: %s\n",array);
    return 0;
}
