//
//  main.c
//  13_11_macroHello
//
//  Created by k21099kk on 2021/07/08.
//

#include <stdio.h>
#define HELLO "Hello World"

int main(int argc, const char * argv[]) {
    printf(HELLO"\n");
    return 0;
}
