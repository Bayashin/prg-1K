//
//  main.c
//  prog1
//
//  Created by k21099kk on 2021/12/22.
//

#include <stdio.h>

struct list{
    int num;
    struct list*next;
};

int main(int argc, const char * argv[]) {
    struct list *root=NULL;
    return 0;
}
