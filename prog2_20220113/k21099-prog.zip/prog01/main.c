//
//  main.c
//  prog01
//
//  Created by k21099kk on 2022/01/12.
//

#include <stdio.h>

typedef struct melem{
    char name[20];
    double height;
    double weight;
    struct melem *next;
}Melem;

int main(int argc, const char * argv[]) {
    
    return 0;
}
