//
//  main.c
//  prog09
//
//  Created by k21099kk on 2021/12/01.
//

#include <stdio.h>

int main(int argc, const char * argv[]) {
    // insert code here...
    printf("Hello, World!\n");
    return 0;
}
