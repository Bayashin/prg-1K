//
//  main.c
//  prog03
//
//  Created by k21099kk on 2021/09/30.
//

#include <stdio.h>

int main(int argc, const char * argv[]) {
    int n;
    printf("number？\n"); scanf("%d",&n);
 
    for (int i=0; i<n; i++) {
        printf("Hello, World!\n");
    }
    
    return 0;
}
