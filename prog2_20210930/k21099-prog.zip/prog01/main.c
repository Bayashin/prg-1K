//
//  main.c
//  prog01
//
//  Created by k21099kk on 2021/09/30.
//

#include <stdio.h>

int main(int argc, const char * argv[]) {
    
    printf("Hello, World!\n");
    return 0;
}
