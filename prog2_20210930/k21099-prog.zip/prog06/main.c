//
//  main.c
//  prog06
//
//  Created by k21099kk on 2021/09/30.
//

#include <stdio.h>
#define NUM 10

int main(int argc, const char * argv[]) {
    
    for (int i=0; i<NUM; i++) {
        printf("Hello, World!\n");
    }
   
    return 0;
}
